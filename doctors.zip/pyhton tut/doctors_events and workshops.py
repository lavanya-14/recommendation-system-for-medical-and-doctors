class MedSocioRecommender:
    def __init__(self):
        self.events = {
            "Continuing Medical Education (CME) Courses": [],
            "Clinical Case-Based Workshops": [],
            "Hands-on Simulation Training": [],
            "Journal Clubs and Research Seminars": [],
            "Advanced Procedural Skills Workshops": [],
            "Leadership and Management Seminars": [],
            "Quality Improvement Workshops": [],
            "Ethics and Professionalism Training": [],
            "Regional Cardiology Conferences": [],
            "Special Interest Group (SIG) Meetings": [],
            "Multidisciplinary Grand Rounds": [],
            "Cross-Specialty Collaborative Workshops": [],
            "International Medical Conventions": []
        }
        self.event_details = {
            "Doctors": ["Educational Events and Workshops", "Professional Development", "Networking and Collaboration Events"],
            "Educational Events and Workshops": ["Continuing Medical Education (CME) Courses", "Clinical Case-Based Workshops", "Hands-on Simulation Training", "Journal Clubs and Research Seminars"],
            "Professional Development": ["Advanced Procedural Skills Workshops", "Leadership and Management Seminars", "Quality Improvement Workshops", "Ethics and Professionalism Training"],
            "Networking and Collaboration Events": ["Regional Cardiology Conferences", "Special Interest Group (SIG) Meetings", "Multidisciplinary Grand Rounds", "Cross-Specialty Collaborative Workshops", "International Medical Conventions"]
        }

    def get_recommendations(self, preferences):
        recommended_events = []
        for category, subcategories in self.event_details.items():
            if category in preferences:
                for subcategory in subcategories:
                    if subcategory in self.events:
                        recommended_events.extend(self.events[subcategory])
        return recommended_events

    def get_detailed_recommendations(self, preferences):
        detailed_recommendations = []
        for category, subcategories in self.event_details.items():
            if category in preferences:
                for subcategory in subcategories:
                    if subcategory in self.events:
                        for event in self.events[subcategory]:
                            detailed_recommendations.append((category, subcategory, event))
        return detailed_recommendations
