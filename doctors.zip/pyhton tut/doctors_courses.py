class MedSocioRecommender:
    def __init__(self):
        self.courses = {
            "Advanced Clinical Training in Specialization": [],
            "Specialty-Specific Procedures and Techniques": [],
            "New Advances in Specialization": [],
            "Leadership and Management in Specialization": [],
            "Ethical Practices in Specialization": [],
            "Public Health and Epidemiology for Specialization": [],
            "Research Methodology in Specialization": [],
            "Healthcare Policy and Management in Specialization": []
        }
        self.course_details = {
            "Specialist Doctors": ["Medical Specialty Courses", "Professional Development Courses", "Special Topics Courses"],
            "Medical Specialty Courses": ["Advanced Clinical Training in Specialization", "Specialty-Specific Procedures and Techniques", "New Advances in Specialization"],
            "Professional Development Courses": ["Leadership and Management in Specialization", "Ethical Practices in Specialization"],
            "Special Topics Courses": ["Public Health and Epidemiology for Specialization", "Research Methodology in Specialization", "Healthcare Policy and Management in Specialization"]
        }

    def get_recommendations(self, preferences):
        recommended_courses = []
        for category, subcategories in self.course_details.items():
            if category in preferences:
                for subcategory in subcategories:
                    if subcategory in self.courses:
                        recommended_courses.extend(self.courses[subcategory])
        return recommended_courses

    def get_detailed_recommendations(self, preferences):
        detailed_recommendations = []
        for category, subcategories in self.course_details.items():
            if category in preferences:
                for subcategory in subcategories:
                    if subcategory in self.courses:
                        for course in self.courses[subcategory]:
                            detailed_recommendations.append((category, subcategory, course))
        return detailed_recommendations
