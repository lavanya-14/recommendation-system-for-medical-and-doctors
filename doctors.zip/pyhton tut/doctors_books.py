class MedSocioRecommender:
    def __init__(self):
        self.books = {
            "Clinical Guidelines": ["Evidence-based Medicine", "Treatment Protocols", "Clinical Decision Making"],
            "General Medical Textbooks": ["Anatomy and Physiology", "Pathophysiology", "Pharmacology"],
            "Healthcare Leadership": ["Leadership and Management", "Practice Management"],
            "Medical Ethics": ["Bioethics", "Ethics in Healthcare"],
            "Teaching and Education": ["Medical Education", "Teaching Skills"],
            "Public Health": ["Epidemiology", "Global Health", "Preventive Medicine"],
            "Research Methodology": ["Clinical Research Methods", "Biostatistics", "Qualitative Research"],
            "Healthcare Policy": ["Health Policy and Reform", "Healthcare Economics", "Legal Aspects of Healthcare"]
        }
        self.book_details = {
            "Doctors": ["Medical Reference Books", "Professional Development Books", "Special Topics Books"],
            "Medical Reference Books": ["Clinical Guidelines", "General Medical Textbooks"],
            "Professional Development Books": ["Healthcare Leadership", "Medical Ethics", "Teaching and Education"],
            "Special Topics Books": ["Public Health", "Research Methodology", "Healthcare Policy"]
        }

    def get_recommendations(self, preferences):
        recommended_books = []
        for category, subcategories in self.book_details.items():
            if category in preferences:
                for subcategory in subcategories:
                    if subcategory in self.books:
                        recommended_books.extend(self.books[subcategory])
        return recommended_books

    def get_detailed_recommendations(self, preferences):
        detailed_recommendations = []
        for category, subcategories in self.book_details.items():
            if category in preferences:
                for subcategory in subcategories:
                    if subcategory in self.books:
                        for book in self.books[subcategory]:
                            detailed_recommendations.append((category, subcategory, book))
        return detailed_recommendations
