class Update:
    def __init__(self, title, category):
        self.title = title
        self.category = category

class Doctor:
    def __init__(self, name, interests):
        self.name = name
        self.interests = interests

class RecommendationSystem:
    def __init__(self, updates):
        self.updates = updates
    
    def recommend(self, doctor):
        recommendations = []
        for update in self.updates:
            if any(interest in update.category for interest in doctor.interests):
                recommendations.append(update)
        return recommendations

# Define news and update categories
medical_news_and_research_updates = [
    Update("Latest Medical Breakthroughs", "Medical News and Research Updates"),
    Update("Clinical Trial Results", "Medical News and Research Updates"),
    Update("New Treatment Guidelines", "Medical News and Research Updates"),
    Update("Healthcare Policy Changes", "Medical News and Research Updates")
]

professional_development_and_career_resources = [
    Update("Continuing Medical Education (CME) Opportunities", "Professional Development and Career Resources"),
    Update("Leadership and Management Insights", "Professional Development and Career Resources"),
    Update("Career Development Tips and Job Openings", "Professional Development and Career Resources"),
    Update("Networking Events and Professional Associations", "Professional Development and Career Resources")
]

specialty_specific_resources = [
    Update("Relevant Journals and Publications", "Specialty-Specific Resources"),
    Update("Case Studies and Clinical Insights", "Specialty-Specific Resources"),
    Update("Specialty-Specific Conferences and Events", "Specialty-Specific Resources")
]

# Combine all news and updates
all_updates = medical_news_and_research_updates + professional_development_and_career_resources + specialty_specific_resources