class Job:
    def __init__(self, title, category):
        self.title = title
        self.category = category

class Doctor:
    def __init__(self, name, specializations, interests):
        self.name = name
        self.specializations = specializations
        self.interests = interests

class RecommendationSystem:
    def __init__(self, jobs):
        self.jobs = jobs
    
    def recommend(self, doctor):
        recommendations = []
        for job in self.jobs:
            if any(specialization in job.title for specialization in doctor.specializations) and any(interest in job.category for interest in doctor.interests):
                recommendations.append(job)
        return recommendations

# Define job categories
clinical_positions = [
    Job("Specialist Physician", "Clinical Positions"),
    Job("Hospitalist", "Clinical Positions")
]

academic_research_positions = [
    Job("Research Scientist", "Academic and Research Positions"),
    Job("Medical Director", "Academic and Research Positions"),
    Job("Clinical Investigator", "Academic and Research Positions"),
    Job("Medical Educator", "Academic and Research Positions")
]

administrative_leadership_positions = [
    Job("Chief Medical Officer (CMO)", "Administrative and Leadership Positions"),
    Job("Department Chair", "Administrative and Leadership Positions"),
    Job("Medical Director of Services", "Administrative and Leadership Positions"),
    Job("Healthcare Executive Leadership Roles", "Administrative and Leadership Positions")
]

# Combine all job positions
all_jobs = clinical_positions + academic_research_positions + administrative_leadership_positions
