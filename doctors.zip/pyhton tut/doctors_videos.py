class MedSocioRecommender:
    def __init__(self):
        self.videos = {
            "Specialty-Specific Lectures": [],
            "Clinical Skills Demonstrations": [],
            "Public Health Discussions": [],
            "Research Methodology Tutorials": [],
            "Healthcare Policy Debates": []
        }
        self.video_details = {
            "Recommendation system": ["Medical Education Videos", "Special Topics Videos"],
            "Medical Education Videos": ["Specialty-Specific Lectures", "Clinical Skills Demonstrations"],
            "Special Topics Videos": ["Public Health Discussions", "Research Methodology Tutorials", "Healthcare Policy Debates"]
        }

    def get_recommendations(self, preferences):
        recommended_videos = []
        for category, subcategories in self.video_details.items():
            if category in preferences:
                for subcategory in subcategories:
                    if subcategory in self.videos:
                        recommended_videos.extend(self.videos[subcategory])
        return recommended_videos

    def get_detailed_recommendations(self, preferences):
        detailed_recommendations = []
        for category, subcategories in self.video_details.items():
            if category in preferences:
                for subcategory in subcategories:
                    if subcategory in self.videos:
                        for video in self.videos[subcategory]:
                            detailed_recommendations.append((category, subcategory, video))
        return detailed_recommendations
