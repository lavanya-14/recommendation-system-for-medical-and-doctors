class FeedItem:
    def __init__(self, title, category):
        self.title = title
        self.category = category

class Doctor:
    def __init__(self, name, interests):
        self.name = name
        self.interests = interests

class RecommendationSystem:
    def __init__(self, feed_items):
        self.feed_items = feed_items
    
    def recommend(self, doctor):
        recommendations = []
        for feed_item in self.feed_items:
            if any(interest in feed_item.category for interest in doctor.interests):
                recommendations.append(feed_item)
        return recommendations

# Define feed categories
staying_current_on_medical_knowledge = [
    FeedItem("Clinical Research & Medical News Feed", "Staying Current on Medical Knowledge"),
    FeedItem("Specialization-Specific Updates Feed", "Staying Current on Medical Knowledge"),
    FeedItem("CME Opportunities Feed", "Staying Current on Medical Knowledge"),
    FeedItem("Healthcare Policy Updates Feed", "Staying Current on Medical Knowledge")
]

community_engagement = [
    FeedItem("Professional Networking", "Community Engagement")
]

# Combine all feed items
all_feed_items = staying_current_on_medical_knowledge + community_engagement

