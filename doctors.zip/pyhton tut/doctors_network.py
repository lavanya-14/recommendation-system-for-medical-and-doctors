class Doctor:
    def __init__(self, id, name, specialization, hospital, city, college):
        self.id = id
        self.name = name
        self.specialization = specialization
        self.hospital = hospital
        self.city = city
        self.college = college

class Student:
    def __init__(self, id, name, college, city, university):
        self.id = id
        self.name = name
        self.college = college
        self.city = city
        self.university = university

class Hospital:
    def __init__(self, name, city):
        self.name = name
        self.city = city

class College:
    def __init__(self, name, city):
        self.name = name
        self.city = city

def recommend_doctors(doctor, doctors):
    recommendations = []

    # Same Specialization
    same_specialization = [d for d in doctors if d.specialization == doctor.specialization and d.id != doctor.id]
    recommendations.extend([d for d in same_specialization if d.hospital == doctor.hospital])
    recommendations.extend([d for d in same_specialization if d.city == doctor.city and d.hospital != doctor.hospital])
    recommendations.extend([d for d in same_specialization if d.city != doctor.city])
    recommendations.extend([d for d in same_specialization if d.hospital == doctor.hospital and d.city != doctor.city])
    recommendations.extend([d for d in same_specialization if d.college == doctor.college])

    # Other Specializations
    other_specializations = [d for d in doctors if d.specialization != doctor.specialization]
    recommendations.extend([d for d in other_specializations if d.hospital == doctor.hospital])
    recommendations.extend([d for d in other_specializations if d.city == doctor.city and d.hospital != doctor.hospital])
    recommendations.extend([d for d in other_specializations if d.city != doctor.city])
    recommendations.extend([d for d in other_specializations if d.hospital == doctor.hospital and d.city != doctor.city])
    recommendations.extend([d for d in other_specializations if d.college == doctor.college])

    return recommendations

def recommend_students(student, students):
    recommendations = []

    # Same College
    same_college = [s for s in students if s.college == student.college and s.id != student.id]
    recommendations.extend(same_college)

    # Other Colleges in the same city
    other_colleges_same_city = [s for s in students if s.city == student.city and s.college != student.college]
    recommendations.extend(other_colleges_same_city)

    # Other Colleges in other cities
    other_colleges_other_cities = [s for s in students if s.city != student.city]
    recommendations.extend(other_colleges_other_cities)

    # Same University in different cities
    same_university_different_cities = [s for s in students if s.university == student.university and s.city != student.city]
    recommendations.extend(same_university_different_cities)

    return recommendations
    
