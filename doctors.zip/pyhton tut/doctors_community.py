# Define communities and users
communities = {
    'Doctors': {
        'Specialization-Based Communities': [],  # No specific specializations listed
        'Academic Communities': {
            'Medical research societies': ['Research Society A', 'Research Society B'],
            'Teaching hospitals networks': ['Hospital Network A', 'Hospital Network B'],
            'Medical school alumni associations': ['Alumni Association A', 'Alumni Association B']
        },
        'Professional Development Communities': {
            'Leadership training programs': ['Leadership Program A', 'Leadership Program B'],
            'Continuing medical education (CME) groups': ['CME Group A', 'CME Group B'],
            'Medical management forums': ['Management Forum A', 'Management Forum B']
        }
    }
}

users = {
    'user1': {
        'interests': ['Research Society A', 'Leadership Program A']
    },
    'user2': {
        'interests': ['Hospital Network B', 'CME Group B']
    }
}

# Recommendation function
def recommend_communities(user_id, communities, users):
    user_interests = users.get(user_id, {}).get('interests', [])
    recommendations = []

    # Iterate through the communities to find matches
    for category, subcategories in communities['Doctors'].items():
        if isinstance(subcategories, dict):
            for subcategory, community_list in subcategories.items():
                for community in community_list:
                    if community in user_interests:
                        recommendations.append(community)
        elif isinstance(subcategories, list):
            for community in subcategories:
                if community in user_interests:
                    recommendations.append(community)

    return recommendations