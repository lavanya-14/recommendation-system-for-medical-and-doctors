Courses:

from collections import defaultdict

class User:
    def __init__(self, user_id, name, current_year, specialization, completed_courses, clinical_interests):
        self.user_id = user_id
        self.name = name
        self.current_year = current_year
        self.specialization = specialization
        self.completed_courses = completed_courses
        self.clinical_interests = clinical_interests

class Course:
    def __init__(self, course_id, title, type, year, specialization, prerequisites, skills):
        self.course_id = course_id
        self.title = title
        self.type = type  # 'curriculum' or 'clinical_skill'
        self.year = year
        self.specialization = specialization
        self.prerequisites = prerequisites
        self.skills = skills

def get_recommendations(user, all_courses):
    recommendations = defaultdict(list)

    for course in all_courses:
        # Check if the course is appropriate for the user's current year and specialization
        if course.year <= user.current_year and (course.specialization == user.specialization or course.specialization == "General"):
            # Check if the user has completed all prerequisites
            if all(prereq in user.completed_courses for prereq in course.prerequisites):
                # Check if the user hasn't already completed this course
                if course.course_id not in user.completed_courses:
                    # 1. Curriculum courses
                    if course.type == 'curriculum':
                        recommendations['curriculum'].append(course)
                    # 2. Clinical skill courses
                    elif course.type == 'clinical_skill':
                        # Prioritize clinical skill courses that match the user's interests
                        if any(interest in course.skills for interest in user.clinical_interests):
                            recommendations['clinical_skill'].append(course)

    # Sort recommendations
    for category in recommendations:
        recommendations[category].sort(key=lambda x: x.year)  # Sort by year

    return recommendations

