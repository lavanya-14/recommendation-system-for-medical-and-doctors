community:

import math

class User:
    def __init__(self, user_id, name, college, location, specializations, research_interests, career_goals):
        self.user_id = user_id
        self.name = name
        self.college = college
        self.location = location  # (latitude, longitude)
        self.specializations = specializations
        self.research_interests = research_interests
        self.career_goals = career_goals

class Group:
    def __init__(self, group_id, name, type, focus):
        self.group_id = group_id
        self.name = name
        self.type = type  # 'academic', 'specialization', or 'career'
        self.focus = focus

def calculate_distance(loc1, loc2):
    # Simplified distance calculation (Euclidean distance)
    return math.sqrt((loc1[0] - loc2[0])**2 + (loc1[1] - loc2[1])**2)

def get_recommendations(current_user, all_users, all_groups, radius):
    recommendations = []

    # 1. Academic communities and research
    academic_groups = [group for group in all_groups if group.type == 'academic']
    for group in academic_groups:
        if any(interest in group.focus for interest in current_user.research_interests):
            recommendations.append(("Academic Group", group))

    # Other colleges within the same radius
    nearby_users = [
        user for user in all_users
        if user.college != current_user.college
        and calculate_distance(user.location, current_user.location) <= radius
    ]
    for user in nearby_users:
        recommendations.append(("Nearby User", user))

    # 2. Specialization Interest Groups
    specialization_groups = [group for group in all_groups if group.type == 'specialization']
    for group in specialization_groups:
        if any(spec in group.focus for spec in current_user.specializations):
            recommendations.append(("Specialization Group", group))

    # 3. Career Preparation Groups
    career_groups = [group for group in all_groups if group.type == 'career']
    for group in career_groups:
        if any(goal in group.focus for goal in current_user.career_goals):
            recommendations.append(("Career Group", group))

    return recommendations

