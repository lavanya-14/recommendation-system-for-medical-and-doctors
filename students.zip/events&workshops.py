Events and workshops:


from collections import defaultdict

class User:
    def __init__(self, user_id, name, year, specialization, skills, research_interests, career_goals):
        self.user_id = user_id
        self.name = name
        self.year = year
        self.specialization = specialization
        self.skills = skills
        self.research_interests = research_interests
        self.career_goals = career_goals

class Workshop:
    def __init__(self, workshop_id, title, category, target_year, specialization, skills, research_area, career_focus):
        self.workshop_id = workshop_id
        self.title = title
        self.category = category  # 'skill', 'specialization', 'research', 'career'
        self.target_year = target_year
        self.specialization = specialization
        self.skills = skills
        self.research_area = research_area
        self.career_focus = career_focus

def get_recommendations(user, all_workshops):
    recommendations = defaultdict(list)

    for workshop in all_workshops:
        # Check if the workshop is appropriate for the user's year
        if workshop.target_year <= user.year:
            # 1. Skill-building workshops
            if workshop.category == 'skill':
                if any(skill not in user.skills for skill in workshop.skills):
                    recommendations['skill'].append(workshop)
            
            # 2. Specialization-specific workshops
            elif workshop.category == 'specialization':
                if workshop.specialization == user.specialization:
                    recommendations['specialization'].append(workshop)
            
            # 3. Research workshops
            elif workshop.category == 'research':
                if workshop.research_area in user.research_interests:
                    recommendations['research'].append(workshop)
            
            # 4. Career development workshops
            elif workshop.category == 'career':
                if workshop.career_focus in user.career_goals:
                    recommendations['career'].append(workshop)

    # Sort recommendations within each category
    for category in recommendations:
        recommendations[category].sort(key=lambda x: x.target_year)

    return recommendations

