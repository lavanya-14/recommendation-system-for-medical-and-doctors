News and updates


from datetime import datetime, timedelta

class User:
    def __init__(self, user_id, name, specialization, interests, exam_focus):
        self.user_id = user_id
        self.name = name
        self.specialization = specialization
        self.interests = interests
        self.exam_focus = exam_focus

class Content:
    def __init__(self, content_id, title, category, specialization, topics, publication_date, importance_score):
        self.content_id = content_id
        self.title = title
        self.category = category  # 'news', 'trend', 'journal', 'research', 'exam'
        self.specialization = specialization
        self.topics = topics
        self.publication_date = publication_date
        self.importance_score = importance_score  # 1-10, with 10 being most important

def get_recommendations(user, all_content, max_recommendations=10):
    recommendations = []
    current_date = datetime.now()

    # 1. Breaking Medical News
    breaking_news = [
        content for content in all_content
        if content.category == 'news'
        and (content.specialization == user.specialization or content.specialization == 'General')
        and (current_date - content.publication_date).days <= 1  # Consider news from the last 24 hours as breaking
        and content.importance_score >= 8  # High importance score for breaking news
    ]
    recommendations.extend(breaking_news)

    # 2. Emerging Trends
    emerging_trends = [
        content for content in all_content
        if content.category == 'trend'
        and (content.specialization == user.specialization or content.specialization == 'General')
        and any(interest in content.topics for interest in user.interests)
    ]
    recommendations.extend(emerging_trends)

    # 3. Latest Medical Journals
    latest_journals = [
        content for content in all_content
        if content.category == 'journal'
        and (content.specialization == user.specialization or content.specialization == 'General')
        and (current_date - content.publication_date).days <= 30  # Journals from the last month
    ]
    recommendations.extend(latest_journals)

    # 4. New Research Breakthroughs in Medicine
    research_breakthroughs = [
        content for content in all_content
        if content.category == 'research'
        and (content.specialization == user.specialization or content.specialization == 'General')
        and content.importance_score >= 7  # High importance score for breakthroughs
    ]
    recommendations.extend(research_breakthroughs)

    # 5. PG Exam Updates
    exam_updates = [
        content for content in all_content
        if content.category == 'exam'
        and content.specialization == user.exam_focus
    ]
    recommendations.extend(exam_updates)

    # Sort all recommendations by importance score and then by publication date
    recommendations.sort(key=lambda x: (-x.importance_score, x.publication_date), reverse=True)

    return recommendations[:max_recommendations]

