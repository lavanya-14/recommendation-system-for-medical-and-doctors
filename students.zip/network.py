Networks:
class User:
    def __init__(self, user_id, name, role, college, university, city, state):
        self.user_id = user_id
        self.name = name
        self.role = role
        self.college = college
        self.university = university
        self.city = city
        self.state = state

def get_recommendations(current_user, all_users):
    recommendations = []
    
    # Priority 1: Senior Doctors - Same college, university, city or state
    senior_doctors = [
        user for user in all_users
        if user.role == "Senior Doctor"
        and (user.college == current_user.college
             or user.university == current_user.university
             or user.city == current_user.city
             or user.state == current_user.state)
    ]
    recommendations.extend(senior_doctors)
    
    # Priority 2: Other Medical students
    # a. Seniors of same college
    same_college_seniors = [
        user for user in all_users
        if user.role == "Medical Student"
        and user.college == current_user.college
        and user.user_id < current_user.user_id  # Assuming lower ID means senior
    ]
    recommendations.extend(same_college_seniors)
    
    # b. Seniors of other colleges
    other_college_seniors = [
        user for user in all_users
        if user.role == "Medical Student"
        and user.college != current_user.college
        and user.user_id < current_user.user_id
    ]
    recommendations.extend(other_college_seniors)
    
    return recommendations

