Books:



class User:
    def __init__(self, user_id, name, curriculum, clinical_interests, exam_focus):
        self.user_id = user_id
        self.name = name
        self.curriculum = curriculum
        self.clinical_interests = clinical_interests
        self.exam_focus = exam_focus

class Resource:
    def __init__(self, resource_id, title, type, topics, difficulty):
        self.resource_id = resource_id
        self.title = title
        self.type = type  # 'book', 'clinical_skill', 'ethics', 'exam_prep'
        self.topics = topics
        self.difficulty = difficulty  # 'beginner', 'intermediate', 'advanced'

def get_recommendations(user, all_resources):
    recommendations = []

    # 1. Books related to the curriculum
    curriculum_books = [
        resource for resource in all_resources
        if resource.type == 'book' and any(topic in user.curriculum for topic in resource.topics)
    ]
    recommendations.extend((1, resource) for resource in curriculum_books)

    # 2. Clinical Skills and Diagnosis
    clinical_resources = [
        resource for resource in all_resources
        if resource.type == 'clinical_skill' and any(interest in resource.topics for interest in user.clinical_interests)
    ]
    recommendations.extend((2, resource) for resource in clinical_resources)

    # 3. Medical Ethics and Professionalism
    ethics_resources = [
        resource for resource in all_resources
        if resource.type == 'ethics'
    ]
    recommendations.extend((3, resource) for resource in ethics_resources)

    # 4. Examination Preparation
    exam_resources = [
        resource for resource in all_resources
        if resource.type == 'exam_prep' and user.exam_focus in resource.topics
    ]
    recommendations.extend((4, resource) for resource in exam_resources)

    # Sort recommendations by priority and then by difficulty
    recommendations.sort(key=lambda x: (x[0], ['beginner', 'intermediate', 'advanced'].index(x[1].difficulty)))

    return recommendations

