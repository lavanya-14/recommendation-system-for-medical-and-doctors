FEED



from datetime import datetime, timedelta

class User:
    def __init__(self, user_id, name, specialization, network, communities, career_stage):
        self.user_id = user_id
        self.name = name
        self.specialization = specialization
        self.network = network  # List of user_ids in the user's network
        self.communities = communities  # List of community_ids the user is part of
        self.career_stage = career_stage  # e.g., 'student', 'resident', 'early_career', 'established'

class Content:
    def __init__(self, content_id, title, category, author_id, community_id, specialization, career_relevance, importance_score, timestamp):
        self.content_id = content_id
        self.title = title
        self.category = category  # 'network_update', 'community_update', 'career_resource', 'critical_info'
        self.author_id = author_id
        self.community_id = community_id
        self.specialization = specialization
        self.career_relevance = career_relevance  # List of career stages this is relevant for
        self.importance_score = importance_score  # 1-10, with 10 being most important
        self.timestamp = timestamp

def get_recommendations(user, all_content, max_recommendations=10):
    recommendations = []
    current_time = datetime.now()

    # 1. Network and Community Updates
    network_community_updates = [
        content for content in all_content
        if (content.category in ['network_update', 'community_update'] and
            (content.author_id in user.network or content.community_id in user.communities) and
            (current_time - content.timestamp).days <= 7)  # Updates from the last week
    ]
    recommendations.extend(network_community_updates)

    # 2. Career Resources
    career_resources = [
        content for content in all_content
        if content.category == 'career_resource' and
        user.career_stage in content.career_relevance and
        (content.specialization == user.specialization or content.specialization == 'General')
    ]
    recommendations.extend(career_resources)

    # 3. Critical Information
    critical_info = [
        content for content in all_content
        if content.category == 'critical_info' and
        content.importance_score >= 8 and
        (content.specialization == user.specialization or content.specialization == 'General')
    ]
    recommendations.extend(critical_info)

    # Sort recommendations
    def sort_key(content):
        category_priority = {
            'network_update': 3,
            'community_update': 3,
            'career_resource': 2,
            'critical_info': 1
        }
        return (category_priority[content.category], -content.importance_score, content.timestamp)

    recommendations.sort(key=sort_key)

    return recommendations[:max_recommendations]

