Jobs:

from datetime import datetime

class User:
    def __init__(self, user_id, name, specialization, experience_years, skills, preferred_locations):
        self.user_id = user_id
        self.name = name
        self.specialization = specialization
        self.experience_years = experience_years
        self.skills = skills
        self.preferred_locations = preferred_locations

class Job:
    def __init__(self, job_id, title, company, specialization, required_experience, salary, location, posting_date, required_skills, trending_score):
        self.job_id = job_id
        self.title = title
        self.company = company
        self.specialization = specialization
        self.required_experience = required_experience
        self.salary = salary
        self.location = location
        self.posting_date = posting_date
        self.required_skills = required_skills
        self.trending_score = trending_score  # A score to represent how trending the job is (higher is more trending)

def get_recommendations(user, all_jobs, salary_threshold, trending_threshold, max_recommendations=10):
    recommendations = []

    # 1. High paying jobs or trending jobs
    high_paying_trending_jobs = [
        job for job in all_jobs
        if (job.salary >= salary_threshold or job.trending_score >= trending_threshold)
        and job.specialization == user.specialization
        and job.required_experience <= user.experience_years
        and job.location in user.preferred_locations
        and set(job.required_skills).issubset(set(user.skills))
    ]

    # Sort high paying and trending jobs by salary (descending) and then by trending score (descending)
    high_paying_trending_jobs.sort(key=lambda x: (-x.salary, -x.trending_score))
    recommendations.extend(high_paying_trending_jobs)

    # 2. Job Market (other relevant jobs)
    other_jobs = [
        job for job in all_jobs
        if job not in high_paying_trending_jobs
        and job.specialization == user.specialization
        and job.required_experience <= user.experience_years
        and job.location in user.preferred_locations
        and set(job.required_skills).issubset(set(user.skills))
    ]

    # Sort other jobs by posting date (most recent first)
    other_jobs.sort(key=lambda x: x.posting_date, reverse=True)
    recommendations.extend(other_jobs)

    return recommendations[:max_recommendations]

