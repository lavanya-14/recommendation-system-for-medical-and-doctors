videos:


class User:
    def __init__(self, user_id, name, curriculum, clinical_interests, study_skills_needed, career_stage):
        self.user_id = user_id
        self.name = name
        self.curriculum = curriculum
        self.clinical_interests = clinical_interests
        self.study_skills_needed = study_skills_needed
        self.career_stage = career_stage

class Video:
    def __init__(self, video_id, title, category, topics, duration):
        self.video_id = video_id
        self.title = title
        self.category = category  # 'educational', 'clinical_skills', 'study_skills', 'motivational', 'interview'
        self.topics = topics
        self.duration = duration  # in minutes

def get_recommendations(user, all_videos):
    recommendations = []

    # 1. Educational videos related to curriculum
    educational_videos = [
        video for video in all_videos
        if video.category == 'educational' and any(topic in user.curriculum for topic in video.topics)
    ]
    recommendations.extend((1, video) for video in educational_videos)

    # 2. Clinical skills videos
    clinical_videos = [
        video for video in all_videos
        if video.category == 'clinical_skills' and any(interest in video.topics for interest in user.clinical_interests)
    ]
    recommendations.extend((2, video) for video in clinical_videos)

    # 3. Time management and study skills videos
    study_skills_videos = [
        video for video in all_videos
        if video.category == 'study_skills' and any(skill in video.topics for skill in user.study_skills_needed)
    ]
    recommendations.extend((3, video) for video in study_skills_videos)

    # 4. Motivational videos
    motivational_videos = [
        video for video in all_videos
        if video.category == 'motivational'
    ]
    recommendations.extend((4, video) for video in motivational_videos)

    # 5. Doctor interviews
    interview_videos = [
        video for video in all_videos
        if video.category == 'interview' and user.career_stage in video.topics
    ]
    recommendations.extend((5, video) for video in interview_videos)

    # Sort recommendations by priority and then by duration (shorter videos first)
    recommendations.sort(key=lambda x: (x[0], x[1].duration))

    return recommendations

